package com.example.test_tasarim;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
